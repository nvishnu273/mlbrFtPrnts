<div class="container">
    <hr>
     <footer>
        <p>&copy; 2017 WordStrap</p>
     </footer>
</div>
<script src="http://code.jquery.com/jquery-1.12.0.min.js">
</script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.js">
</script>
</body>
</html>