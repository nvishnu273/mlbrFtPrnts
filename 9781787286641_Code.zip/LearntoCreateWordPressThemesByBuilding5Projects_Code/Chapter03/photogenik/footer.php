</div> 
        </div>
    </div>
    <footer>
    <p><?php bloginfo('name');  ?> &copy; 2017</p>
 	</footer>
 	  <?php wp_footer(); ?>
</body>
</html>